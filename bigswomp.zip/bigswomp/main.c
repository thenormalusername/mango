#include <inttypes.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <time.h>
#include <stdbool.h>

#include "cubiomes/biomenoise.h"
#include "cubiomes/finders.h"
#include "cubiomes/generator.h"

#define THREADS 8
#define BATCH_SIZE 16384
#define START_SEED 8939610142224231157ULL

typedef struct {
  BiomeNoise *t, *h, *c, *e, *w;
} ClimateNoises;

typedef struct {
  double t, h, c, e, w;
} ClimateValues;


static atomic_uint_fast64_t next_seed = 0;

FILE *outp;

static inline float singleoct(Xoroshiro *px, uint64_t xlo, uint64_t xhi){
    uint64_t lo=xNextLong(px), hi=xNextLong(px);
    Xoroshiro xr={lo^xlo, hi^xhi}; xSkipN(&xr,1);
    return fabsf(((uint32_t)(xNextLong(&xr)>>32)&0xFFFFFF)*5.960464478E-8f - 0.5f);
}

static int crunch(uint64_t seed){
  Xoroshiro xr; xSetSeed(&xr, seed);
  uint64_t lo=xNextLong(&xr), hi=xNextLong(&xr);

  Xoroshiro erosion0={lo^0xd02491e6058f6fd8, hi^0x4792512c94c17a80};
  float e0aoffset=singleoct(&erosion0,0x082fe255f8be6631,0x4e96119e22dedc81);
  float e0boffset=singleoct(&erosion0,0x082fe255f8be6631,0x4e96119e22dedc81);

  Xoroshiro erosion1={lo^0xd02491e6058f6fd8, hi^0x4792512c94c17a80};
  float e1aoffset=singleoct(&erosion1,0x0ef68ec68504005e,0x48b6bf93a2789640);
  float e1boffset=singleoct(&erosion1,0x0ef68ec68504005e,0x48b6bf93a2789640);

  if ((e0aoffset + e0boffset) * 0.35f + (e1aoffset + e1boffset) * 0.15f > 0.05f) return 0;

  Xoroshiro cont0={lo^0x83886c9d0ae3a662, hi^0xafa638a61b42e8ad};
  float c0aoffset=singleoct(&cont0,0x082fe255f8be6631,0x4e96119e22dedc81);
  float c0boffset=singleoct(&cont0,0x082fe255f8be6631,0x4e96119e22dedc81);

  if (c0aoffset + c0boffset > 0.25f) return 0;
  return 1;
}

static double sample(BiomeNoise *bn, int a, int b, int x, int z) {
  double v = 0;
  if (a) {
    OctaveNoise *on = &bn->climate[bn->nptype].octA;
    for (int i = 0; i < on->octcnt; i++) {
      if (a & (1 << i)) {
        PerlinNoise *pn = on->octaves + i;
        double l = pn->lacunarity;
        v += samplePerlin(pn, x * l, 0, z * l, 0, 0) * pn->amplitude;
      }
    }
  }
  if (b) {
    OctaveNoise *on = &bn->climate[bn->nptype].octB;
    for (int i = 0; i < on->octcnt; i++) {
      if (b & (1 << i)) {
        PerlinNoise *pn = on->octaves + i;
        double l = pn->lacunarity * (337.0 / 331.0);
        v += samplePerlin(pn, x * l, 0, z * l, 0, 0) * pn->amplitude;
      }
    }
  }
  return v * bn->climate[bn->nptype].amplitude;
}

static int eval1(ClimateNoises *n, int qx, int qz){ 
  double temp = sample(n->t, 0b11, 0b11, qx, qz); if (temp < -0.4500 || temp > 0.2000) return 0;
  if(sample(n->e, 0b1111, 0b1111, qx, qz) < 0.5500) return 0;
  if(sample(n->c, 0b1111, 0b1111, qx, qz) < -0.1100) return 0;
  double wrd = sample(n->w, 0b111, 0b111, qx, qz); if (wrd < -0.4000 || wrd > 0.4000) return 0;
  return 1;
 }
static int eval2(ClimateNoises *n, int qx, int qz){ 
  if(sample(n->t, 0b11, 0b11, qx, qz) < 0.2000) return 0;
  if(sample(n->e, 0b1111, 0b1111, qx, qz) < 0.5500) return 0;
  if(sample(n->c, 0b1111, 0b1111, qx, qz) < -0.1100) return 0;
  double wrd = sample(n->w, 0b111, 0b111, qx, qz); if (wrd < -0.4000 || wrd > 0.4000) return 0;
  return 1;
 }

static int climateparameters(ClimateNoises *n, int qx, int qz) {
  if(sample(n->t, 0b11, 0b11, qx, qz) < -0.4500) return 0;
  if(sample(n->e, 0b1111, 0b1111, qx, qz) < 0.5500) return 0;
  if(sample(n->c, 0b1111, 0b1111, qx, qz) < -0.1100) return 0;
  double wrd = sample(n->w, 0b111, 0b111, qx, qz); if (wrd < -0.4000 || wrd > 0.4000) return 0;
  return 1;
}

static int flood(ClimateNoises *n, int x, int z, int (*eval)(ClimateNoises *, int, int)) {
    int origin_x = x / 8;
    int origin_z = z / 8;
    uint8_t visited[384][384] = {0};
    int queue_x[147456];
    int queue_z[147456];
    int head = 0;
    int tail = 0;
    int area = 0;
    int64_t sum_x = 0;
    int64_t sum_z = 0;
    visited[192][192] = 1;
    queue_x[tail] = 192;
    queue_z[tail] = 192;
    tail++;
    while (head < tail)
    {
        int lx = queue_x[head];
        int lz = queue_z[head];
        int target_x = lx + origin_x - 192;
        int target_z = lz + origin_z - 192;
        head++;
        area++;
        sum_x += (int64_t)target_x;
        sum_z += (int64_t)target_z;
        int dx[4] = {1, -1, 0, 0};
        int dz[4] = {0, 0, 1, -1};
        for (int i = 0; i < 4; i++)
        {
            int nx = lx + dx[i];
            int nz = lz + dz[i];
            if (nx >= 0 && nx < 384 && nz >= 0 && nz < 384 && !visited[nz][nx])
            {
                visited[nz][nx] = 1;
                int n_target_x = nx + origin_x - 192;
                int n_target_z = nz + origin_z - 192;
                int result = eval(n, n_target_x * 8, n_target_z * 8);
                if (result == 1)
                {
                    queue_x[tail] = nx;
                    queue_z[tail] = nz;
                    tail++;
                }
                else if (result == -1)
                {
                    return 0;
                }
            }
        }
    }
    return area * 64;
}

static int biomesize(ClimateNoises *n, int *id, uint64_t seed, int qx, int qz) {
  int samplerange = 256;
  int area = 0;
  int temporary = 0;

  setClimateParaSeed(n->c, seed, 0, NP_CONTINENTALNESS, 8);
  setClimateParaSeed(n->e, seed, 0, NP_EROSION, 8);
  setClimateParaSeed(n->w, seed, 0, NP_WEIRDNESS, 6);
  setClimateParaSeed(n->h, seed, 0, NP_HUMIDITY, 4);
  setClimateParaSeed(n->t, seed, 0, NP_TEMPERATURE, 4);
  
  for (int qx1=qx-samplerange; qx1<=qx+samplerange; qx1+=128) {
    for (int qz1=qz-samplerange; qz1<=qz+samplerange; qz1+=128) {
      if (!climateparameters(n, qx1, qz1)) continue;
      if (sample(n->t, 0b11, 0b11, qx1, qz1) < 0.2000) {
        int temporary = flood(n, qx1, qz1, eval1);
        if (temporary > area) area = temporary, *id = 0;

      } else {
        int temporary = flood(n, qx1, qz1, eval2);
        if (temporary > area) area = temporary, *id = 1;
      }
    }
  }
  return area;
}

static int biomecoverage(ClimateNoises *n, int qx, int qz) {
  int normalhitcount = 0, mangrovehitcount = 0;
  int samplerange = 1024;

  for (int qx1=qx-samplerange; qx1<=qx+samplerange; qx1+=32) {
    for (int qz1=qz-samplerange; qz1<=qz+samplerange; qz1+=32) {

      if (sample(n->e, 0b11, 0b11, qx1, qz1) < 0.5500) continue;
      if (sample(n->c, 0b1, 0b1, qx1, qz1) < 0.1000) continue;
      double tsample = sample(n->t, 0b1, 0b1, qx1, qz1);
      if (tsample <= -0.4500) continue;
      if (tsample <= 0.2000) {
        normalhitcount++;
      } else {
        mangrovehitcount++;
      }
      
    }
  }
  if (normalhitcount >= 800) {
    //printf("normal ");
    return normalhitcount;
  }
  if (mangrovehitcount >= 800) {
    //printf("mangrove %d %d   ", qx*4, qz*4);
    return mangrovehitcount;
  }
  return 0;
}

static int prefilter(BiomeNoise *e, int qx, int qz) {
  int hitcount = 0;
  int samplerange = 1024;

  for (int qx1=qx-samplerange; qx1<=qx+samplerange; qx1+=128) {
    for (int qz1=qz-samplerange; qz1<=qz+samplerange; qz1+=128) {
      if (sample(e, 0b11, 0b11, qx1, qz1) > 0.7500) hitcount++;
    }
  }
  return hitcount;
}

static int erosion_b_area(BiomeNoise *e, int qx, int qz) {
  int hitcount = 0;
  int samplerange = 1024;

  for (int qx1=qx-samplerange; qx1<=qx+samplerange; qx1+=256) {
    for (int qz1=qz-samplerange; qz1<=qz+samplerange; qz1+=256) {
      if (sample(e, 0b0, 0b11, qx1, qz1) > 0.2000) hitcount++;
    }
  }
  return hitcount;
}

static void tiling(ClimateNoises *n, uint64_t seed, int qx, int qz) {
  setClimateParaSeed(n->e, seed, 0, NP_EROSION, 2);

  //center of the first full erosion tile in world border;  border of the last one;  tile repeatition distance
  int head = -7340032, tail = 7405568, lacunarity = 131072;

  for (int qxtile=(head+qx); qxtile<tail; qxtile+=lacunarity) {
    for (int qztile=(head+qz); qztile<tail; qztile+=lacunarity) {

      if (sample(n->e, 0b0, 0b1, qxtile, qztile) < 0.2000) continue;
      
      //samples at the angles of the perfect triangle, reversed relative to such of the a octave
      bool a = sample(n->e, 0b0, 0b1, qxtile-650, qztile+375) > 0.2000;
      bool b = sample(n->e, 0b0, 0b1, qxtile+650, qztile+375) > 0.2000;
      bool c = sample(n->e, 0b0, 0b1, qxtile, qztile-750) > 0.2000;
      if (!(a||b||c)) continue;

      setClimateParaSeed(n->e, seed, 0, NP_EROSION, 4);
      if (erosion_b_area(n->e, qxtile, qztile) < 30) continue;

      setClimateParaSeed(n->c, seed, 0, NP_CONTINENTALNESS, 2);
      if (sample(n->c, 0b1, 0b1, qxtile, qztile) < 0.1000) continue;

      //int precount = prefilter(n->e, qxtile, qztile);
      //if (precount < 35) continue;
      if (prefilter(n->e, qxtile, qztile) < 40) continue;

      setClimateParaSeed(n->t, seed, 0, NP_TEMPERATURE, 2);
      //setClimateParaSeed(n->w, seed, 0, NP_WEIRDNESS, 4)
      //int biomecount = biomecoverage(n, qxtile, qztile);
      if (biomecoverage(n, qxtile, qztile) < 800) continue;
      
      int biomeid = -1;
      int area = biomesize(n, &biomeid, seed, qxtile, qztile);
      if (area < 800000) continue;
      char biomes[3][15] = {"Swamp", "Mangrove Swamp", "ERROR"};

      int x = qxtile * 4, z = qztile * 4;
      printf("%" PRId64 "   %d %d       %d    %s\n", seed, x, z, area, biomes[biomeid]);
    }
  }
  return;
}

static int erosion_area(BiomeNoise *e, uint64_t seed, int qx, int qz) {

  //samples are done at the angles of the perfect triangle
  bool a = sample(e, 0b1, 0b0, qx-650, qz-375) > 0.3000;
  bool b = sample(e, 0b1, 0b0, qx+650, qz-375) > 0.3000;
  bool c = sample(e, 0b1, 0b0, qx, qz+750) > 0.3000;

  if (a||b||c) {

    setClimateParaSeed(e, seed, 0, NP_EROSION, 3);
    int samplerange = 1024;
    int hitcount = 0;

    for (int qx1=qx-samplerange; qx1<=qx+samplerange; qx1+=256) {
      for (int qz1=qz-samplerange; qz1<=qz+samplerange; qz1+=256) {
        if (sample(e, 0b11, 0b0, qx1, qz1) > 0.2000) hitcount++;
      }
    }

    return hitcount;

  }
  return 0;
}

static void erosion_start_point(ClimateNoises *n, uint64_t seed) {

  setClimateParaSeed(n->e, seed, 0, NP_EROSION, 1);
  int range=65536;

  //qx, qz - coordinates on 1:4 scale 
  for (int qx=-range; qx<=range; qx+=1024) {
    for (int qz=-range; qz<=range; qz+=1024) {
  
      if (sample(n->e, 0b1, 0b0, qx, qz) < 0.3000) continue;
      //printf("startpoint\n");
      if (erosion_area(n->e, seed, qx, qz) < 40) continue;
      //printf("area\n");
      tiling(n, seed, qx, qz);
    }
  }
  //bool test1 = 0;
  //if (sample(n->e, 0b1, 0b0, 0, 0) > 0.3000) {
  //  test1 = erosion_area(n, seed, 0, 0) > 20;
  //}
  //return test1;
}

static void *worker(void *arg) {
  Generator g;
  setupGenerator(&g, MC_NEWEST, 0);
  BiomeNoise t, h, c, e, w;
  t = h = c = e = w = g.bn;
  ClimateNoises n = {&t, &h, &c, &e, &w};
  while (1) {
    uint64_t start = atomic_fetch_add(&next_seed, BATCH_SIZE);
    uint64_t end = start + BATCH_SIZE;
    for (uint64_t seed = start; seed < end; seed++) {
      if (!crunch(seed)) continue;
      erosion_start_point(&n, seed);
      //printf("%" PRId64 "\n", seed);
    }
  }
  return NULL;
}

int main(void) {
  srand((unsigned int)time(NULL));
  uint64_t seed = 0;
  for (int i = 0; i < 4; i++) {
    seed = (seed << 16) | (uint64_t)(rand() & 0xFFFF);
  }
  atomic_store(&next_seed, seed);
  outp = fopen("output.txt", "a");
  pthread_t threads[THREADS];
  for (int i = 0; i < THREADS; i++) {
    pthread_create(&threads[i], NULL, worker, NULL);
  }
  for (int i = 0; i < THREADS; i++) {
    pthread_join(threads[i], NULL);
  }
  return 0;
}
